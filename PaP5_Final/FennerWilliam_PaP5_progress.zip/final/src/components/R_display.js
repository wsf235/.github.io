/**
 * Created by MasterAnseen on 10/13/17.
 */
import React, { Component } from 'react'
import Recipe from '../functions/recipe_class'
import Data_Check from '../functions/data_check'
import ReactDOM from 'react-dom'

const styles={
    exObj:{
        margin: '20px',
        padding: '10px',
        width: '270px',
        height: '150px',
        float: 'left',
        backgroundColor: 'rgba(71,76,126,0.4)',
        backgroundImage: 'url("")',
        borderRadius: '5%',
        display: 'flex',
        flexDirection: 'column'
    }
};

class List extends Component{
    constructor(props){
        super(props);
        //this.delete_symbol();
        this.state ={
            list: JSON.parse(localStorage.getItem('recipe_list'))
        }
    }

    show_item(i){

        return <tr style={styles.exObj}>
            <td>Recipe: {this.state.list[i].title}</td>
            <td>Description: {this.state.list[i].desc}</td>
            <td className="edit">Edit</td>
            <td className="remove">Remove</td>
        </tr>
    }
    /*
    delete_symbol = (e) => {
        //var delete_button = document.getElementsByClassName('remove');
        //for(var o = 0; o < delete_button.length; o++)
        //{
        //    delete_button[o].addEventListener('click', function(e)
        //    {
        //        e.preventDefault();
                console.log(e);

                var rekt = e.target.parentNode;
                var spot = Array.from(e.target.parentNode.parentNode.children).indexOf(rekt);

                console.log(rekt);
                ReactDOM.unmountComponentAtNode(document.getElementById('root'));
                e.target.parentNode.parentNode.removeChild(rekt);
                this.Delete(spot);
        //    });
        //}
    };
    */
    Delete = (id) => {
        var count = JSON.parse(localStorage.getItem('bank_transactions'));
        count.splice(id, 1);
        localStorage.setItem('recipe_list', JSON.stringify(count));
    };

    show_list(){
        var obj = [];

        for(var i = 0; i < this.state.list.length; i++){
            obj.push(this.show_item(i));
        }
        //this.delete_symbol();
        return obj;
    }


    render(){

        return(
            <section className="_Transaction">
                <table>
                    <tbody>
                    {this.show_list()}
                    </tbody>
                </table>

            </section>
        );
    }
}

export default List