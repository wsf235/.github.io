/**
 * Created by MasterAnseen on 10/9/17.
 */
import React, { Component } from 'react'
import { NavLink } from 'react-router-dom'

class Major extends Component{
    render(){
        return(
            <nav className="">
                <NavLink to="/search/beef"> Beef</NavLink>
                <NavLink to="/search/eggs"> Eggs</NavLink>
                <NavLink to="/search/chicken"> Chicken</NavLink>
                <NavLink to="/search/pork"> Pork</NavLink>
                <NavLink to="/search/vegan"> Vegan</NavLink>
                <NavLink to="/search/vegitable"> Vegitable</NavLink>
                <NavLink to="/search/soup"> Soup</NavLink>
                <NavLink to="/search/italian"> Italian</NavLink>
                <NavLink to="/search/spanish"> Spanish</NavLink>
            </nav>
        );
    }
}

export default Major