/**
 * Created by MasterAnseen on 10/8/17.
 */
import React, { Component } from 'react'
import Data_Check from '../functions/data_check'
import Request from '../functions/search_recipe'
class Search extends Component{

    constructor(props){
        super(props);
        this.state = {
            data: Request(window.location.pathname.substr(8)),
            disp: JSON.parse(localStorage.getItem('temp_recipe_list'))
        }


    }

    display = () => {
        console.log(this.state.data);
        console.log(this.state.disp);

        var arr = [];
         for(var i = 0; i < this.state.disp.length; i++){
            arr.push(<div className='result'>
            <img src={this.state.disp[i].img} alt='Nothing here' />
            <div id='info'>
            <h3>{this.state.disp[i].title}</h3>
            <p>Recipe Link: <a href={this.state.disp[i].desc}>Link</a></p>
            </div>
            </div>);
         }
        return arr;
    };

    componentWillReceiveProps = (nextProps) => {
        if(this.props != nextProps)
            return true;
    };

    render(){
        Data_Check();

        return(
            <section className="">
                <div className="wipe">{this.display()}</div>
            </section>
        );
    }
}



export default Search