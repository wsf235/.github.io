/**
 * Created by MasterAnseen on 10/8/17.
 */
import React, { Component } from 'react'
import Data_Check from '../functions/data_check'
import Request from '../functions/search_recipe'
class Featured extends Component{

    constructor(props){
        super(props);
        Data_Check();
        Request(window.location.pathname.substr(8));
        this.state = {
            items: JSON.parse(localStorage.getItem('temp_recipe_list'))//,
            //func:
        }

    }



    render(){
        return(
            <section className="">
                <p>{window.location.pathname}</p>
                <div>{this.props.name}</div>

            </section>
        );
    }
}



export default Featured